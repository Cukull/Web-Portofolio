---
name: Organic Editorial
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#434934'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#747a62'
  outline-variant: '#c3c9ae'
  surface-tint: '#4c6700'
  primary: '#4c6700'
  on-primary: '#ffffff'
  primary-container: '#c6ff34'
  on-primary-container: '#567400'
  inverse-primary: '#a3d800'
  secondary: '#5d5f5b'
  on-secondary: '#ffffff'
  secondary-container: '#e0e0db'
  on-secondary-container: '#62635f'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#ececec'
  on-tertiary-container: '#696a6b'
  error: '#F15B5B'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bdf528'
  primary-fixed-dim: '#a3d800'
  on-primary-fixed: '#151f00'
  on-primary-fixed-variant: '#394d00'
  secondary-fixed: '#e3e3de'
  secondary-fixed-dim: '#c6c7c2'
  on-secondary-fixed: '#1a1c19'
  on-secondary-fixed-variant: '#454744'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  background-warm: '#FAFAF7'
  text-slate: '#707070'
  border-soft: '#EAEAEA'
  hover-accent: '#B7F12C'
  success: '#56C271'
  warning: '#FFCC66'
typography:
  display-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 84px
    fontWeight: '800'
    lineHeight: 92px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 54px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  button:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 15px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  section-gap-desktop: 140px
  section-gap-mobile: 80px
  container-max: 1200px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 24px
---

## Brand & Style

This design system embodies a premium editorial aesthetic that balances Swiss-style structural rigor with an organic, friendly warmth. It is designed for high-end portfolios where the work takes center stage, supported by a "quiet" interface that prioritizes legibility and spatial harmony.

The style is a sophisticated blend of **Minimalism** and **Modern Editorial**. It leverages expansive whitespace (the "breath" of the design), high-contrast typography, and a tactile sense of depth achieved through soft shadows and subtle tonal layering. The brand personality is professional yet curious—a meticulous developer who values craft over clutter.

**Design Pillars:**
- **Intentional Whitespace:** Margin and padding are not empty spaces; they are active design elements that guide the eye.
- **Micro-Tactility:** Use of low-opacity shadows and "Hover Lift" effects to make digital elements feel physically responsive.
- **Chromatic Restraint:** A neutral, warm base allows the lime accent to function as a high-precision tool for focus and action.

## Colors

The palette is anchored in a "Warm White" ecosystem, avoiding the clinical coldness of pure hex white for the primary canvas. This creates a calm, paper-like quality essential for an editorial feel.

- **Background Strategy:** Use `#FAFAF7` for the page body and `#FFFFFF` (Surface) for interactive cards and elevated containers to create a natural hierarchy without heavy borders.
- **The Accent:** Lime (`#C6FF34`) is the sole energetic outlier. It must be used sparingly—only for primary calls to action, active navigation states, and small functional highlights.
- **Typography Tiers:** Heading text uses the "Carbon" neutral for maximum contrast, while secondary text uses "Slate Gray" to reduce visual noise in metadata or descriptions.

## Typography

The typographic system relies on a high-contrast scale. **Bricolage Grotesque** provides a distinctive, slightly quirky personality for headlines, while **Inter** ensures utilitarian clarity for body copy.

- **Scale Philosophy:** Headings should be oversized to create an editorial impact, while body text remains compact and highly legible. 
- **Tightened Kerning:** For display sizes, use negative letter spacing to maintain a cohesive, "locked-in" look.
- **Styling Note:** Use "Black" (900) and "ExtraBold" (800) weights of Bricolage Grotesque for hero sections to emphasize the modern, bold intent of the design system.

## Layout & Spacing

This design system uses a **12-column fluid grid** contained within a maximum width of 1440px, with a primary content well of 1200px.

- **Vertical Rhythm:** Large vertical gaps (120px–160px) between sections are mandatory to maintain the "Premium/Calm" feeling.
- **Grid Behavior:** Elements should generally span 4, 6, 8, or 12 columns. Avoid odd-numbered spans to keep the layout feeling architectural.
- **Mobile Reflow:** On mobile devices, the 12-column grid collapses to a single column with 24px side margins. Section spacing should be halved to maintain momentum without excessive scrolling.

## Elevation & Depth

Hierarchy is established through **tonal layering** and **ambient shadows** rather than heavy lines.

- **Surface Strategy:** The base level is the Background (`#FAFAF7`). Level 1 elements (Cards/Inputs) use the Surface color (`#FFFFFF`) with a subtle 1px border (`#EAEAEA`).
- **Shadow Profile:** Shadows must be felt, not seen. Use very low opacity (3-5%) with a large blur radius (40px+) and a slight Y-axis offset.
- **Depth Color:** Instead of pure black shadows, use a tinted shadow derived from the primary text color (Carbon) to ensure it feels integrated with the warm background.
- **Interactions:** On hover, use a "Lift" effect—increase the shadow's blur and slightly decrease the element's Y-position to simulate physical elevation.

## Shapes

The shape language is organic and progressively rounded based on the scale of the component.

- **Small (12px):** Used for input fields, small buttons, and tags.
- **Medium (20px):** Standard setting for project cards and secondary containers.
- **Large (28px):** Used for featured section containers and large imagery.
- **Hero/Extra Large (36px):** Reserved for primary hero cards or major layout wrappers.
- **Icons:** Use **Lucide** icons exclusively. Maintain a consistent 2px stroke width with "round" join and cap settings to match the UI's softness.

## Components

### Buttons
- **Primary:** Filled with Lime (`#C6FF34`), Text in Carbon (`#171717`). High visibility, rounded (12px).
- **Secondary:** Outlined with Border (`#EAEAEA`). Background is transparent or Surface white.
- **Behavior:** All buttons should have a 150ms transition for background-color and a subtle scale-up (1.02x) on hover.

### Cards
- White Surface (`#FFFFFF`) background.
- 1px Soft Gray border.
- 20px or 28px corner radius.
- Large padding (32px+) to maintain the spacious editorial feel.

### Input Fields
- Subtle Soft Cream (`#F5F5F0`) background with no border in resting state.
- Focus state: White background with a 1px Lime border.
- 12px roundedness.

### Navigation (Navbar)
- Floating "Island" design. 
- Transparent background with a `backdrop-filter: blur(12px)`.
- Pill-shaped (rounded-full).

### Lists & Project Cards
- Use "Editorial" layouts: large imagery on top with minimal, high-contrast text below.
- Project cards should use "Hover Reveal" for metadata to keep the initial view clean.